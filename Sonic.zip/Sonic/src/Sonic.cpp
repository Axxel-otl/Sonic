#include "Sonic.h"

// Constructor
Sonic::Sonic() {
    // Constructor vacío
}

// Configura los pines y los guarda como miembros
void Sonic::attach(uint8_t trig, uint8_t echo) {
    this->trig = trig;
    this->echo = echo;
    pinMode(this->trig, OUTPUT);
    pinMode(this->echo, INPUT);
}

// Dispara el ultrasonido y devuelve la distancia en cm con timeout en maxCm
void Sonic::scream(long &dist, long maxCm) {
    digitalWrite(this->trig, LOW);
    delayMicroseconds(5);
    digitalWrite(this->trig, HIGH);
    delayMicroseconds(10);
    digitalWrite(this->trig, LOW);

    unsigned long timeout = maxCm * 58; // 1 cm ≈ 58 us ida y vuelta
    dist = pulseIn(this->echo, HIGH, timeout);
    dist = dist / 58; // Convertir microsegundos a cm
    if(dist == 0){
        dist = -1;
        return;
    }
}
