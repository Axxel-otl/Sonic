#pragma once
#include <Arduino.h>

class Sonic {
public:
    Sonic();
    void attach(uint8_t trig, uint8_t echo);
    void scream(long &dist, long maxCm = 400);
private:
    uint8_t trig;
    uint8_t echo;
};
